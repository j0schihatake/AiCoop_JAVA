namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model {
    public enum FacilityType {
        ControlCenter,
        VehicleFactory
    }
}
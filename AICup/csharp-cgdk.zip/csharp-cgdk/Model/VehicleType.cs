namespace Com.CodeGame.CodeWars2017.DevKit.CSharpCgdk.Model {
    public enum VehicleType {
        Arrv,
        Fighter,
        Helicopter,
        Ifv,
        Tank
    }
}
import model.Vehicle;
import java.util.*;

//Масштабный участок игрового пространства.
public class Sector {

    //Число юнитов в секторе, которое отображает наличие целого отряда.
    public int squadCount = 10;

    public int player_unit_count = 0;
    public int enemy_unit_count = 0;

    //Левый верхний угол сектора;
    public Position startPoint = new Position(0,0);

    //Правый нижний угол сектора:
    public Position finishPoint = new Position(0,0);

    //Центр сектора:
    public INTPosition centerPoint = new INTPosition(0,0);

    // Теперь для формирования отчета и быстрого получения сектора из списка потребуется уникальный ключ
    public INTPosition sector_key = new INTPosition(0,0);

    //Спиок всей техники в секторе:
    public ArrayList<Long> allVehicleInSector = new ArrayList<>();

    //Чтобы каждый раз не создавать ключи соседнх секторов:
    INTPosition upSector = new INTPosition(0, 0);
    INTPosition downSector = new INTPosition(0, 0);
    INTPosition leftSector = new INTPosition(0, 0);
    INTPosition rightSector = new INTPosition(0, 0);
    INTPosition leftUPSector = new INTPosition(0, 0);
    INTPosition leftDownSector = new INTPosition(0, 0);
    INTPosition rightUPSector = new INTPosition(0, 0);
    INTPosition rightDownSector = new INTPosition(0, 0);

    //Конкретное число едениц каждого типа в секторе;
    public int HELECOPTERInSectorCount = 0;
    public int FIGHTERInSectorCount = 0;
    public int TANKInSectorCount = 0;
    public int BMPInSectorCount = 0;
    public int REMInSectorCount = 0;

    //Конкретное число едениц врага каждого типа в секторе;
    public int HELECOPTEREnemyInSectorCount = 0;
    public int FIGHTEREnemyInSectorCount = 0;
    public int TANKEnemyInSectorCount = 0;
    public int BMPEnemyInSectorCount = 0;
    public int REMEnemyInSectorCount = 0;

    //Настраиваем текущий сектор:
    public void configure(MyStrategy strategy){

        //Сектор сверху:
        INTPosition upSector = new INTPosition(0, 0);
        upSector.y = this.centerPoint.y + (int) strategy.yStep;
        upSector.x = this.centerPoint.x;

        //Сектор снизу:
        INTPosition downSector = new INTPosition(0, 0);
        downSector.y = this.centerPoint.y - (int) strategy.yStep;
        downSector.x = this.centerPoint.x;

        //Сектор слева:
        INTPosition leftSector = new INTPosition(0, 0);
        leftSector.y = this.centerPoint.y;
        leftSector.x = this.centerPoint.x - (int) strategy.xStep;

        //Сектор справа:
        INTPosition rightSector = new INTPosition(0, 0);
        rightSector.y = this.centerPoint.y;
        rightSector.x = this.centerPoint.x + (int) strategy.xStep;

        //Сектор слева-сверху:
        INTPosition leftUPSector = new INTPosition(0, 0);
        leftUPSector.y = this.centerPoint.y + (int) strategy.yStep;
        leftUPSector.x = this.centerPoint.x - (int) strategy.xStep;

        //Сектор слева-снизу:
        INTPosition leftDownSector = new INTPosition(0, 0);
        leftDownSector.y = this.centerPoint.y - (int) strategy.yStep;
        leftDownSector.x = this.centerPoint.x - (int) strategy.xStep;

        //Сектор справа-вверху:
        INTPosition rightUPSector = new INTPosition(0, 0);
        rightUPSector.y = this.centerPoint.y + (int) strategy.yStep;
        rightUPSector.x = this.centerPoint.x + (int) strategy.xStep;

        //Сектор справа-внизу:
        INTPosition rightDownSector = new INTPosition(0, 0);
        rightDownSector.y = this.centerPoint.y - (int) strategy.yStep;
        rightDownSector.x = this.centerPoint.x + (int) strategy.xStep;
    }

    //Метод обновляет все данные о количествах юнитов в секторе:
    public void updateSectorInfo(MyStrategy strategy){

        HELECOPTERInSectorCount = 0;
        FIGHTERInSectorCount = 0;
        TANKInSectorCount = 0;
        BMPInSectorCount = 0;
        REMInSectorCount = 0;

        HELECOPTEREnemyInSectorCount = 0;
        FIGHTEREnemyInSectorCount = 0;
        TANKEnemyInSectorCount = 0;
        BMPEnemyInSectorCount = 0;
        REMEnemyInSectorCount = 0;

        player_unit_count = 0;
        enemy_unit_count = 0;

        for(int i = 0; i < allVehicleInSector.size(); i++) {

            //нул может вернуться если технику уничтожили:
            if (strategy.getVehicleByID(allVehicleInSector.get(i))!= null) {

            Vehicle vehicle = strategy.getVehicleByID(allVehicleInSector.get(i));

                if (equalsLong(vehicle.getPlayerId(),strategy.me.getId())) {
                    //Отмечаем количество едениц техники каждого типа
                    player_unit_count ++;
                    switch (vehicle.getType()) {
                        case ARRV:
                            HELECOPTERInSectorCount ++;
                            break;
                        case FIGHTER:
                            FIGHTERInSectorCount ++;
                            break;
                        case HELICOPTER:
                            TANKInSectorCount ++;
                            break;
                        case IFV:
                            REMInSectorCount ++;
                            break;
                        case TANK:
                            BMPInSectorCount ++;
                            break;
                    }
                }
                if (!equalsLong(vehicle.getPlayerId(),strategy.me.getId())) {
                    enemy_unit_count ++;
                    switch (vehicle.getType()) {
                        case ARRV:
                            HELECOPTEREnemyInSectorCount ++;
                            break;
                        case FIGHTER:
                            FIGHTEREnemyInSectorCount ++;
                            break;
                        case HELICOPTER:
                            TANKEnemyInSectorCount ++;
                            break;
                        case IFV:
                            REMEnemyInSectorCount ++;
                            break;
                        case TANK:
                            BMPEnemyInSectorCount ++;
                            break;
                    }
                }
            }
        }
        if(strategy.debug & strategy.mapLevel_debug){

            System.out.println("Всего в данном секторе замечено " + allVehicleInSector.size() + " боевых едениц");
            System.out.println("Всего в данном секторе замечено " + player_unit_count + " боевых едениц игрока");
            System.out.println("Всего в данном секторе замечено " + enemy_unit_count + " боевых едениц противника");

        }
    }

    //Реализуем сравнение позиций:
    boolean equalsLong(Long id, Long id2){
        boolean result = false;
        //результат -1 при 1 значение меньше, 0 значения равны, 1 первое значение больше.
        if((Double.compare(id, id2) == 0)){
            result = true;
        }
        return result;
    }
}

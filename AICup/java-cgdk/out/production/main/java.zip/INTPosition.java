// Аналог Position, только с елочисленными значениями координат.
// (Для быстрого доступа в мапе)
public class INTPosition {
    //Координата X:
    public int x = 0;

    //Координата Y:
    public int y = 0;

    //Конструктор
    INTPosition(double x, double y){
        this.x = (int)x;
        this.y = (int)y;
    }
}

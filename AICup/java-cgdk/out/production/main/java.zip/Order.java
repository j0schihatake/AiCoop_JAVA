import model.Vehicle;

//Данный класс представляет собой отложенное действие:
public class Order {

    //Тип действия:
    public type_order type;
    public enum type_order{
        move,
        move_squad,
        rotate,
        select,
        group,
        build,
    }

    public Squad order_squad = null;

    //Приоритет данного приказа(1 - затирает предыдущий приказ, 0 - нет)
    public int prioritet = 0;

    //Сектор, нахождение отряда в котором будет означать прекращение текущего приказа как вполнен.
    public Sector completeSector = null;

    //Координаты:
    public double x = 0;
    public double y = 0;
    public double x2 = 0;
    public double y2 = 0;

    //Для групп необходимо значение группы:
    public int group_number = 0;

    //Данный параметр видоизменяет поведение методов на указанное.
    public int modificator = 0;

    //Целевая техника(к которой данный приказ применяется)
    public Vehicle target_vehicle = null;

    //Тип техники к которому применяется данный приказ.
    public vehicle_type type_vehicle;
    public enum vehicle_type{
        FVI,
        HELECOPTER,
        TANK,
        REM,
        BMP,
    }

    public boolean complete = false;

    //Установить точку назначения:
    public void setDestination(Sector sector){
        this.x = sector.centerPoint.x;
        this.y = sector.centerPoint.y;
        this.completeSector = sector;
    }
}

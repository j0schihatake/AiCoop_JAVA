import model.*;

import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.stream.Stream;

@SuppressWarnings({"UnsecureRandomNumberGeneration", "FieldCanBeLocal", "unused", "OverlyLongMethod"})
public final class MyStrategy implements Strategy {
    /**
     * Список целей для каждого типа техники, упорядоченных по убыванию урона по ним.
     */
    private static final Map<VehicleType, VehicleType[]> preferredTargetTypesByVehicleType;

    static {
        preferredTargetTypesByVehicleType = new EnumMap<>(VehicleType.class);

        preferredTargetTypesByVehicleType.put(VehicleType.FIGHTER, new VehicleType[] {
                VehicleType.HELICOPTER, VehicleType.FIGHTER
        });

        preferredTargetTypesByVehicleType.put(VehicleType.HELICOPTER, new VehicleType[] {
                VehicleType.TANK, VehicleType.ARRV, VehicleType.HELICOPTER, VehicleType.IFV, VehicleType.FIGHTER
        });

        preferredTargetTypesByVehicleType.put(VehicleType.IFV, new VehicleType[] {
                VehicleType.HELICOPTER, VehicleType.ARRV, VehicleType.IFV, VehicleType.FIGHTER, VehicleType.TANK
        });

        preferredTargetTypesByVehicleType.put(VehicleType.TANK, new VehicleType[] {
                VehicleType.IFV, VehicleType.ARRV, VehicleType.TANK, VehicleType.FIGHTER, VehicleType.HELICOPTER
        });
    }

    private Random random;

    private TerrainType[][] terrainTypeByCellXY;
    private WeatherType[][] weatherTypeByCellXY;

    public Player me;
    public World world;
    public Game game;
    private Move move;

    //Переменные для определения стартовых позиций отрядов:
    public start_position_type tank_start;
    public start_position_type bmp_start;
    public start_position_type rem_start;
    public start_position_type fighter_start;
    public start_position_type helecopter_start;
    public enum start_position_type{
        up,
        center,
        down,
        left,
        right,
        left_up,
        left_down,
        right_up,
        right_down,
    }

    public boolean debug = false;
    public boolean mapLevel_debug = false;

    //Класс представляющий собой NI интеллект из N коммандующих.
    private NITactics tactics = new NITactics();

    //-----------------------------------------Списки техники:
    private final Map<Long, Vehicle> vehicleById = new HashMap<>();
    private final Map<Long, Integer> updateTickByVehicleId = new HashMap<>();
    private final Queue<Consumer<Move>> delayedMoves = new ArrayDeque<>();

    //Формирую для ускорения отдельно список каждого вида техники:
    public ArrayList<Long> FIGHTERList = new ArrayList<>();
    public ArrayList<Long> HELECOPTERList = new ArrayList<>();
    public ArrayList<Long> TANKList = new ArrayList<>();
    public ArrayList<Long> BMPList = new ArrayList<>();
    public ArrayList<Long> REMList = new ArrayList<>();
    public ArrayList<Long> IFVList = new ArrayList<>();

    //Обобщенные списки юнитов игрока(используются при стартовой инициализации):
    public ArrayList<Long> allGameVehicle = new ArrayList<>();

    //-----------------------------------------Стартовые позиции отрядов:
    //Стартовые позиции отрядов:
    Position HELECOPTERSquadPosition = new Position(0,0);
    Position FIGHTERSquadPosition = new Position(0,0);
    Position TANKSquadPosition = new Position(0, 0);
    Position BMPSquadPosition = new Position(0,0);
    Position REMSquadPosition = new Position(0,0);

    double min = 0;
    double middle = 0;
    double max = 0;

    //Список стартовых позиций:
    ArrayList<Position> startSquadPositionList = new ArrayList<>();

    //Стартовая позиция слева:
    Position left = new Position(34.5,93.5);
    //Стартовая позиция справа:
    Position right = new Position(152.5,93.5);
    //Стартовая позиция сверху:
    Position up = new Position(93.5,34.5);
    //Стартовая позиция снизу:
    Position down = new Position(93.5,152.5);
    //Стартовая позиция по центру:
    Position center = new Position(93.5,93.5);
    //Стартовая позиция слева вверху:
    Position left_up = new Position(34.5,34.5);
    //Стартовая позиция слева внизу:
    Position left_down = new Position(35.5,152.35);
    //Стартовая позиция справа вверху;
    Position right_up = new Position(152.5,34.5);
    //Стартовая позиция справа внизу:
    Position right_down = new Position(152.5,152.5);

    //-------------------------------------------------------ОТРЯДЫ:
    //Список обьектов характеризующих имеющиеся у игрока отряды:
    public ArrayList<Squad> allPlayerSquad = new ArrayList<>();
    public Map<Integer, Squad> allSquadPlayerMap = new HashMap<>() ;

    public Squad squad_0_Fighter = null;
    public Squad squad_1_Helecopter = null;
    public Squad squad_2_Tank = null;
    public Squad squad_3_Bmp = null;
    public Squad squad_4_REM = null;

    //-------------------------------------------------------СЕКТОРА:
    //Шаги по сетке между секторами:
    public double xStep = 0;
    public double yStep = 0;

    //Список секторов на карте:
    public ArrayList<Sector> allSectorList = new ArrayList<>();            //все сектора на карте

    //Мапа - секторов (сентр сектора/ обьект сектора)
    public Map<INTPosition, Sector> allSectorMap = new HashMap<>();

    //Специальная мапа для быстрого и однозначного доступа к секторам нейронного офицера:
    public Map<INTPosition, Sector> officer_map = new HashMap<>();

    //Число секторов на ось:
    public int XSectorCount = 5;
    int YSectorCount = 5;

    //--------------------------------------------------------ПРИКАЗЫ:
    //Список всех текущих приказов:
    private ArrayList<Order> allOrder = new ArrayList<>();
    private Order active_order = null;

    //Число доступных действий в данном интервале тиков:
    private int action = 0;

    // количество доступных действий:
    private int actionCount = 0;

    // период обновления действий:
    private int actionRepeatCount = 0;

    //Получаем технику по id:
    public Vehicle getVehicleByID(Long id){
        Vehicle returned = null;
        returned = vehicleById.get(id);
        return returned;
    }

    /**
     * Основной метод стратегии, осуществляющий управление армией. Вызывается каждый тик.
     *
     * @param me    Информация о вашем игроке.
     * @param world Текущее состояние мира.
     * @param game  Различные игровые константы.
     * @param move  Результатом работы метода является изменение полей данного объекта.
     */
    @Override
    public void move(Player me, World world, Game game, Move move) {

        //Обновление информации об изменениях с прошлого тика:
        initializeTick(me, world, game, move);

        //Тут углубляемся в стратегию:
        move();
    }

    /**
     * Сохраняем все входные данные в полях класса для упрощения доступа к ним, а также актуализируем сведения о каждой
     * технике и времени последнего изменения её состояния.
     */
    private void initializeTick(Player me, World world, Game game, Move move) {
        this.me = me;
        this.world = world;
        this.game = game;
        this.move = move;
        Vehicle vehicle_selecter = null;

        //Данная часть кода отрабатывает: когда юнит был создан фабрикой, или выехал на нас из тумана.
        for (Vehicle vehicle : world.getNewVehicles()) {

            vehicleById.put(vehicle.getId(), vehicle);

            Vehicle vehicle2 = vehicleById.get(vehicle.getId());
            updateTickByVehicleId.put(vehicle.getId(), world.getTickIndex());

            //Только при появлении техники на всякий случай отсортировываем ее по типовым спискам;
            switch (vehicle2.getType()){
                case FIGHTER:
                    if(!FIGHTERList.contains(vehicle2.getId())) {
                        FIGHTERList.add(vehicle2.getId());
                    }
                    break;
                case HELICOPTER:
                    if(!HELECOPTERList.contains(vehicle2.getId())) {
                        HELECOPTERList.add(vehicle2.getId());
                    }
                    break;
                case IFV:
                    if(!BMPList.contains(vehicle2.getId())) {
                        BMPList.add(vehicle2.getId());
                    }
                    break;
                case TANK:
                    if(!TANKList.contains(vehicle2.getId())) {
                        TANKList.add(vehicle2.getId());
                    }
                    break;
                case ARRV:
                    if(!REMList.contains(vehicle2.getId())) {
                        REMList.add(vehicle2.getId());
                    }
                    break;
            }
        }

        //данный участок кода передает информацию о всех изменениях.
        for (VehicleUpdate vehicleUpdate : world.getVehicleUpdates()) {

            long vehicleId = vehicleUpdate.getId();

            //Тут так-же удаляю из общего списка ссылку:
            vehicle_selecter = vehicleById.get(vehicleId);

            if (vehicleUpdate.getDurability() == 0) {
                vehicleById.remove(vehicleId);
                updateTickByVehicleId.remove(vehicleId);

                switch (vehicle_selecter.getType()){
                    case FIGHTER:
                        if(FIGHTERList.contains(vehicle_selecter.getId())) {
                            FIGHTERList.remove(vehicle_selecter.getId());
                        }
                        break;
                    case HELICOPTER:
                        if(HELECOPTERList.contains(vehicle_selecter.getId())) {
                            HELECOPTERList.remove(vehicle_selecter.getId());
                        }
                        break;
                    case IFV:
                        if(BMPList.contains(vehicle_selecter.getId())) {
                            BMPList.remove(vehicle_selecter.getId());
                        }
                        break;
                    case TANK:
                        if(TANKList.contains(vehicle_selecter.getId())) {
                            TANKList.remove(vehicle_selecter.getId());
                        }
                        break;
                    case ARRV:
                        if(REMList.contains(vehicle_selecter.getId())) {
                            REMList.remove(vehicle_selecter.getId());
                        }
                        break;
                }

                //Обновляем информацию о данной технике в секторах:
                updateVehicleInSectors(vehicle_selecter);
            } else {
                //Обновляем информацию о данной технике в секторах:
                vehicleById.put(vehicleId, new Vehicle(vehicleById.get(vehicleId), vehicleUpdate));
                updateTickByVehicleId.put(vehicleId, world.getTickIndex());

                //Обновляем информацию о данной технике в секторах:
                updateVehicleInSectors(vehicle_selecter);
            }
        }
    }

    //Метод выполняется лишь один раз, обозначая переменную player_unit_count(чтобы отметить юниты игрока)
    private void startUpdatePayerVehicleInSector(){

        for(int i = 0; i < allSectorList.size();i++){
            Sector next = allSectorList.get(i);
            if(next.sector_key.x == 0 && next.sector_key.y == 0){
                next.updateSectorInfo(this);
            }
            if(next.sector_key.x == 0 && next.sector_key.y == 1){
                next.updateSectorInfo(this);
            }
            if(next.sector_key.x == 0 && next.sector_key.y == 2){
                next.updateSectorInfo(this);
            }
            if(next.sector_key.x == 1 && next.sector_key.y == 0){
                next.updateSectorInfo(this);
            }
            if(next.sector_key.x == 1 && next.sector_key.y == 1){
                next.updateSectorInfo(this);
            }
            if(next.sector_key.x == 1 && next.sector_key.y == 2){
                next.updateSectorInfo(this);
            }
        }
    }

    //Метод выполняет распределение техники по секторам, относительно координат.
    private void updateVehicleInSectors(Vehicle vehicle){

        if(vehicle.getDurability() > 0) {
            for (int i = 0; i < allSectorList.size(); i++) {
                Sector selected = allSectorList.get(i);

                //Тут может случиться null если техника уничтожена:
                if (vehicleById.containsKey(vehicle.getId())) {
                    Vehicle original = vehicleById.get(vehicle.getId());
                    //Тут выполняем проверку(находится ли наша техника в данном секторе):
                    if ((original.getX() > selected.startPoint.x & original.getY() > selected.startPoint.y)
                            & ((original.getX() < selected.finishPoint.x & original.getY() < selected.finishPoint.y)
                            & !selected.allVehicleInSector.contains(original.getId()))) {

                        //Добавляем технику в список этого сектора:
                        selected.allVehicleInSector.add(original.getId());

                        //проверяем, нет ли данной еденицы техники во всех остальных секторах:
                        for (int n = 0; n < allSectorList.size(); n++) {
                            Sector next = allSectorList.get(n);
                            if (!selected.sector_key.equals(next.sector_key)) {
                                if (next.allVehicleInSector.contains(original.getId())) {
                                    next.allVehicleInSector.remove(original.getId());
                                }
                            }
                        }
                    }
                }else{
                    vehicleById.remove(vehicle.getId());
                    //проверяем, нет ли данной еденицы техники во всех остальных секторах:
                    for (int n = 0; n < allSectorList.size(); n++) {
                        Sector next = allSectorList.get(n);
                        if (!selected.sector_key.equals(next.sector_key)) {
                            if (next.allVehicleInSector.contains(vehicle.getId())) {
                                next.allVehicleInSector.remove(vehicle.getId());
                            }
                        }
                    }
                }
            }
        }
    }

    private Stream<Vehicle> streamVehicles(Ownership ownership, VehicleType vehicleType) {
        Stream<Vehicle> stream = vehicleById.values().stream();

        switch (ownership) {
            case ALLY:
                stream = stream.filter(vehicle -> vehicle.getPlayerId() == me.getId());
                break;
            case ENEMY:
                stream = stream.filter(vehicle -> vehicle.getPlayerId() != me.getId());
                break;
            default:
        }

        if (vehicleType != null) {
            stream = stream.filter(vehicle -> vehicle.getType() == vehicleType);
        }

        return stream;
    }

    private Stream<Vehicle> streamVehicles(Ownership ownership) {
        return streamVehicles(ownership, null);
    }

    private Stream<Vehicle> streamVehicles() {
        return streamVehicles(Ownership.ANY);
    }

    private enum Ownership {
        ANY,

        ALLY,

        ENEMY
    }

    /**
     * Основная логика нашей стратегии.
     */
    private void move() {

        //Очищение счетчика действий:
        recleanActionCount();

        //Обрабатываем накопившиеся задания:
        orderator();

        // Выполняем инициализацию(один раз на старте :) Unity3D.Start()):
        if (this.world.getTickIndex() == 0) {

            //Получаем начальные условия игры:
            actionRepeatCount = game.getActionDetectionInterval();
            actionCount = game.getBaseActionCount();

            //Быстренько формируем пустые отряды:
            squad_0_Fighter = new Squad(this);
            squad_1_Helecopter = new Squad(this);
            squad_2_Tank = new Squad(this);
            squad_3_Bmp = new Squad(this);
            squad_4_REM = new Squad(this);

            //Передаем ссылку на стратегию модулю оффицера.
            tactics.strategy = this;

            //Формируем представление о карте и о начальных позициях отрядов:
            start();

            //Песочница для стратегии:
            sandsbox();

            //Один раз на старте обновляем наших юнитов игрока для отображения:
            startUpdatePayerVehicleInSector();
        }

        //В сучае дебага требуется обновлять информацию о каждом секторе каждый тик:
        if(debug){
            for(int i = 0; i < allSectorList.size(); i++){
                Sector next = allSectorList.get(i);
                next.updateSectorInfo(this);
            }
            //для тестирования выводим в консоль текущее состояние карты(каждый тик):
            tactics.debug_map(tactics.getGameInfo());
        }
    }

    // Метод обрабатывает ордерав порядке возрастания индекса:
    void orderator(){

        //Если есть хотя бы одно задание:
        if(allOrder.size() > 0) {

            //Проверяем а есть ли в текущем интервале тиков доступные действия:
            if (action < actionCount) {

                // Если нет текущего активного задания:
                if (active_order == null) {

                    //Получаем следующее по порядку задание.
                    active_order = allOrder.get(0);

                    //Теперь в зависимости от типа задания выполняем метод:
                    switch (active_order.type) {
                        case build:
                            break;
                        case move:
                            moveOrder(active_order.x, active_order.y, active_order,active_order.group_number);
                            break;
                        case rotate:
                            break;
                        case group:
                            groupOrder(active_order.group_number, active_order.modificator, active_order);
                            break;
                        case select:
                            selectVehicle(active_order.target_vehicle, active_order.modificator, active_order, active_order.x, active_order.y, active_order.x2, active_order.y2, 0);
                            break;
                    }

                    //Теперь отменяем данное задание если оно выполнено
                    // (задачи на передислокацию переводятся в статус complete самими отрядами):
                    if (active_order.complete == true) {
                        if(debug) {
                            System.out.println("Выполнен еще один приказ с типом: " + active_order.type);
                        }
                        allOrder.remove(0);
                        active_order = null;
                    }
                }
            }
            if (allOrder.size() == 0) {
                //Если тактический офицер уже подготовлен:
                if (tactics.tactikal_officer != null) {
                    if (debug) {
                        System.out.println("Принято решение задействовать тактического оффицера");
                    }
                    //Если у солдат нет приказов, то подключаем нашего оффицера:
                    tactics.work();
                }
            }
        }
        //Так-же пробегаем все имеющиеся отряды и проверяем, если у них имеются активные приказы(на перемещение)
    }

    //Подсчитываем актуальность числа оставшихся доступных действий:
    void recleanActionCount(){
        //Если текущее значение тиков делится на 60 без остатка(значит прошел еще один цикл):
        if(actionRepeatCount!=0) {
            if (this.world.getTickIndex() % actionRepeatCount == 0) {
                if(debug) {
                    System.out.println("Цикл доступности действий пройден, доступные действия обновлены");
                    System.out.println("В списке приказов имеется: " + allOrder.size());
                    if(allOrder.size()>0) {
                        System.out.println("Следующий приказ который будет выполнен имеет тип: " + allOrder.get(0).type);
                    }
                }
                action = 0;
            } else if (action >= actionCount) {
                if(debug) {
                    System.out.println("Внимание достигнут лимит доступных действий (" + actionCount + "), в текущем цикле.");
                    System.out.println("В списке приказов имеется: " + allOrder.size());
                    if(allOrder.size()>0) {
                        System.out.println("Следующий приказ который будет выполнен имеет тип: " + allOrder.get(0).type);
                    }
                }
            }
        }
    }

    //В данном методе происходит формирование цифровой версии стартовой ситуации:
    void start(){

        tactics.debug = debug;

        //Рассчитываем сектора:
        setSectors();

        //Получаем стартовые позиции всех пяти отрядов:
        getStartPosition();

        //Теперь создаем и обучаем наш коммитет про принятию решений: оффицеры!
        tactics.start();
    }

    // Метод подразделяет все игровое пространство на более общирные сектора:
    void setSectors(){
        //Рассчитываем размер сектора исходя из количества:
        double sectorHeight = world.getHeight()/XSectorCount;
        double sectorWidth = world.getWidth()/YSectorCount;

        //Теперь создаем необходимые сектора:
        for(int y = 0; y < YSectorCount; y++){
            for(int x = 0; x < XSectorCount; x++){

                int i = x;
                int j = y;

                //Создаем новый обьект типа Sector():
                Sector newSector = new Sector();

                //Расчитываем исходя из размеров точки нового сектора;
                Position newStartPoint = new Position((double)(x * sectorWidth),(double)(y * sectorHeight));
                Position newFinishPoint = new Position((double)(x * sectorWidth) + sectorWidth,(double)(y * sectorWidth) + sectorHeight);
                xStep = (newFinishPoint.x - newStartPoint.x)/2;
                yStep = (newFinishPoint.y - newStartPoint.y)/2;
                INTPosition newCenterPoint = new INTPosition((int)(xStep) + newStartPoint.x,(int)(yStep) + newStartPoint.y);

                //Так-же формируем специальную "карту" для оффицера:
                INTPosition sector_key = new INTPosition(i,j);
                newSector.sector_key = sector_key;
                officer_map.put(sector_key, newSector);

                //Устанавливаем полученные размеры в сектор:
                newSector.startPoint = newStartPoint;
                newSector.finishPoint = newFinishPoint;
                newSector.centerPoint = newCenterPoint;

                if(debug) {
                System.out.println("Добавлен новый сектор: номер сектора i = " + x + ", номер сектора j = " + y
                        + ", newStartPoint.x = " + newStartPoint.x + ", newStartPoint.y = " + newStartPoint.y
                        + ", newFinishPoint.x = " + newFinishPoint.x + ", newFinishPoint.y = " + newFinishPoint.y
                        + ", newCenterPoint.x = " + newCenterPoint.x + ", newCenterPoint.y = " + newCenterPoint.y);
                System.out.println("Ключ нового сектора: sector_key.x = " + sector_key.x + ", sector_key.y = " + sector_key.y);
                }

                //Добавляем новый настроенный сектор в список:
                allSectorList.add(newSector);
                allSectorMap.put(newSector.centerPoint, newSector);
            }
        }
        if(debug){System.out.println("Было сформированно следующее количество секторов: " + allSectorList.size());}
    }

    //Получаем центры формаций отрядов каждого вида:
    void getStartPosition(){

        getCenterFighter();
        getCenterHelecopter();
        getCenterTank();
        getCenterBmp();
        getCenterRem();

        //Добавляем стартовые позиции в список:
        startSquadPositionList.add(HELECOPTERSquadPosition);
        startSquadPositionList.add(FIGHTERSquadPosition);
        startSquadPositionList.add(TANKSquadPosition);
        startSquadPositionList.add(BMPSquadPosition);
        startSquadPositionList.add(REMSquadPosition);

        //Рассчет координат выделения:
        calculate_selection();
    }

    public void getCenterFighter(){
        // Также находим центр формации наших FIGHTER ...
        FIGHTERSquadPosition.x = streamVehicles(
                Ownership.ALLY, VehicleType.FIGHTER
        ).mapToDouble(Vehicle::getX).average().orElse(Double.NaN);

        FIGHTERSquadPosition.y = streamVehicles(
                Ownership.ALLY, VehicleType.FIGHTER
        ).mapToDouble(Vehicle::getY).average().orElse(Double.NaN);
    }
    public void getCenterHelecopter(){
        // Также находим центр формации наших HELECOPTER ...
        HELECOPTERSquadPosition.x = streamVehicles(
                Ownership.ALLY, VehicleType.HELICOPTER
        ).mapToDouble(Vehicle::getX).average().orElse(Double.NaN);

        HELECOPTERSquadPosition.y = streamVehicles(
                Ownership.ALLY, VehicleType.HELICOPTER
        ).mapToDouble(Vehicle::getY).average().orElse(Double.NaN);
    }
    public void getCenterTank(){
        // Также находим центр формации наших TANK ...
        TANKSquadPosition.x = streamVehicles(
                Ownership.ALLY, VehicleType.TANK
        ).mapToDouble(Vehicle::getX).average().orElse(Double.NaN);

        TANKSquadPosition.y = streamVehicles(
                Ownership.ALLY, VehicleType.TANK
        ).mapToDouble(Vehicle::getY).average().orElse(Double.NaN);
    }
    public void getCenterBmp(){
        // Также находим центр формации наших BMP ...
        BMPSquadPosition.x = streamVehicles(
                Ownership.ALLY, VehicleType.IFV
        ).mapToDouble(Vehicle::getX).average().orElse(Double.NaN);

        BMPSquadPosition.y = streamVehicles(
                Ownership.ALLY, VehicleType.IFV
        ).mapToDouble(Vehicle::getY).average().orElse(Double.NaN);

    }
    public void getCenterRem(){
        // Также находим центр формации наших БРЭМ ...
        REMSquadPosition.x = streamVehicles(
                Ownership.ALLY, VehicleType.ARRV
        ).mapToDouble(Vehicle::getX).average().orElse(Double.NaN);

        REMSquadPosition.y = streamVehicles(
                Ownership.ALLY, VehicleType.ARRV
        ).mapToDouble(Vehicle::getY).average().orElse(Double.NaN);
    }

    //Метод опираясь на центры расположения отрядов выполняет расчет, и выбор отрядов.
    void calculate_selection(){

        min = startSquadPositionList.get(1).x;             //Значение минимальной координаты
        max = startSquadPositionList.get(1).x;             //Значение максимальной координаты

        //Прогоним по x и по y:
        for(int i = 0; i < startSquadPositionList.size(); i++){
            Position next = startSquadPositionList.get(i);
            //Отбираем минимальную координату:
            if(min > next.x){
                min = next.x;
            }
            if(min > next.y){
                min = next.y;
            }
        }

        //Прогоним по x и по y:
        for(int j = 0; j < startSquadPositionList.size(); j++){
            Position next = startSquadPositionList.get(j);
            //Отбираем максимальную координату:
            if(max < next.x){
                max = next.x;
            }
            if(max < next.y){
                max = next.y;
            }
        }

        middle = min;          //Значение средней координаты

        //Прогоним по x и по y:
        for(int k = 0; k < startSquadPositionList.size(); k++){
            Position next = startSquadPositionList.get(k);
            //Отбираем среднюю координату:
            if(min < next.x & next.x < max){
                middle = next.x;
            }
            if(min < next.y & next.y < max){
                middle = next.y;
            }
        }

        //Формируем вектора позиции:
        up.x = middle;
        up.y = min;

        down.x = middle;
        down.y = max;

        left.x = min;
        left.y = middle;

        right.x = max;
        right.y = middle;

        left_up.x = min;
        left_up.y = min;

        left_down.x = min;
        left_down.y = max;

        right_up.x = max;
        right_up.y = min;

        right_down.x = max;
        right_down.y = max;

        center.x = middle;
        center.y = middle;

        if(debug) {
            System.out.println(min);
            System.out.println(middle);
            System.out.println(max);
        }
    }

    //Метод в котором собственно и экспериментируем с тактикой:
    void sandsbox(){

        //Определяем где какой отряд стоит:
        returnStartPositionSituation();

        // Согласно первому плану, до включения тактического офицера требуется сформировать
        // отряды и задать им номер для быстрого последующео выбора:

        //Выбираем все самолеты и назначаем им группу:
        setSelectOrder(6, vehicleById.get(FIGHTERList.get(0)), 0,0,0,0, 0);
        setGroupOrder(0,1);

        //Выбираем все вертолеты и назначаем им группу:
        setSelectOrder(6, vehicleById.get(HELECOPTERList.get(0)), 0,0,0,0, 1);
        setGroupOrder(1,1);

        /*
        //Выбираем все Танки и назначаем им группу:
        setSelectOrder(6, vehicleById.get(BMPList.get(0)), 0,0,0,0,2);
        setGroupOrder(2,1);

        //Выбираем все БМП и назначаем им группу:
        setSelectOrder(6, vehicleById.get(BMPList.get(0)), 0,0,0,0,3);
        setGroupOrder(3,1);

        //Выбираем все самолеты и назначаем им группу:
        setSelectOrder(6, vehicleById.get(REMList.get(0)), 0,0,0,0,4);
        setGroupOrder(4,1);
        */

        // Далее когда последовательность указанных выше ордеров будет выполнена,
        // за анализ игровых ситуаций примется тактический оффицер,
        // который при отсутствии приказов в списке приказов будет отдавать новые.
    }

    //Метод сравнением определяет где какой отряд стоит:
    void returnStartPositionSituation(){

        //Находим позицию самолетов:
        if(FIGHTERSquadPosition.equals(down)){
            if(debug) {
                System.out.println("Самолеты внизу");
            }
            fighter_start = start_position_type.down;
        }
        if(FIGHTERSquadPosition.equals(up)){
            if(debug) {
                System.out.println("Самолеты вверху");
            }
            fighter_start = start_position_type.up;
        }
        if(FIGHTERSquadPosition.equals(left)){
            if(debug) {
                System.out.println("Самолеты слева");
            }
            fighter_start = start_position_type.left;
        }
        if(FIGHTERSquadPosition.equals(right)){
            if(debug) {
                System.out.println("Самолеты справа");
            }
            fighter_start = start_position_type.right;
        }
        if(FIGHTERSquadPosition.equals(left_up)){
            if(debug) {
                System.out.println("Самолеты в левом верхнем углу");
            }
            fighter_start = start_position_type.left_up;
        }
        if(FIGHTERSquadPosition.equals(left_down)){
            if(debug) {
                System.out.println("Самолеты в левом нижнем углу");
            }
            fighter_start = start_position_type.left_down;
        }
        if(FIGHTERSquadPosition.equals(center)){
            if(debug) {
                System.out.println("Самолеты по центру");
            }
            fighter_start = start_position_type.center;
        }
        if(FIGHTERSquadPosition.equals(right_up)){
            if(debug) {
                System.out.println("Самолеты в правом верхнем углу");
            }
            fighter_start = start_position_type.right_up;
        }
        if(FIGHTERSquadPosition.equals(right_down)){
            if(debug) {
                System.out.println("Самолеты в правом нижнем углу");
            }
            fighter_start = start_position_type.right_down;
        }

        //Находим позицию вертолетов:
        if(HELECOPTERSquadPosition.equals(down)){
            if(debug) {
                System.out.println("Вертолеты внизу");
            }
            helecopter_start = start_position_type.down;
        }
        if(HELECOPTERSquadPosition.equals(up)){
            if(debug) {
                System.out.println("Вертолеты вверху");
            }
            helecopter_start = start_position_type.up;
        }
        if(HELECOPTERSquadPosition.equals(left)){
            if(debug) {
                System.out.println("Вертолеты слева");
            }
            helecopter_start = start_position_type.left;
        }
        if(HELECOPTERSquadPosition.equals(right)){
            if(debug) {
                System.out.println("Вертолеты справа");
            }
            helecopter_start = start_position_type.right;
        }
        if(HELECOPTERSquadPosition.equals(left_up)){
            if(debug) {
                System.out.println("Вертолеты в левом верхнем углу");
            }
            helecopter_start = start_position_type.left_up;
        }
        if(HELECOPTERSquadPosition.equals(left_down)){
            if(debug) {
                System.out.println("Вертолеты в нижнем левом углу");
            }
            helecopter_start = start_position_type.left_down;
        }
        if(HELECOPTERSquadPosition.equals(center)){
            if(debug) {
                System.out.println("Вертолеты по центру");
            }
            helecopter_start = start_position_type.center;
        }
        if(HELECOPTERSquadPosition.equals(right_up)){
            if(debug) {
                System.out.println("Вертолеты в правом верхнем углу");
            }
            helecopter_start = start_position_type.right_up;
        }
        if(HELECOPTERSquadPosition.equals(right_down)){
            if(debug) {
                System.out.println("Вертолеты внизу");
            }
            helecopter_start = start_position_type.right_down;
        }

        //Находим позицию REM:
        if(REMSquadPosition.equals(down)){
            if(debug) {
                System.out.println("REM внизу");
            }
            rem_start = start_position_type.down;
        }
        if(REMSquadPosition.equals(up)){
            if(debug) {
                System.out.println("REM вверху");
            }
            rem_start = start_position_type.up;
        }
        if(REMSquadPosition.equals(left)){
            if(debug) {
                System.out.println("REM слева");
            }
            rem_start = start_position_type.left;
        }
        if(REMSquadPosition.equals(right)){
            if(debug) {
                System.out.println("REM справа");
            }
            rem_start = start_position_type.right;
        }
        if(REMSquadPosition.equals(left_up)){
            if(debug) {
                System.out.println("REM в левом верхнем углу");
            }
            rem_start = start_position_type.left_up;
        }
        if(REMSquadPosition.equals(left_down)){
            if(debug) {
                System.out.println("REM в нижнем левом углу");
            }
            rem_start = start_position_type.left_down;
        }
        if(REMSquadPosition.equals(center)){
            if(debug) {
                System.out.println("REM по центру");
            }
            rem_start = start_position_type.center;
        }
        if(REMSquadPosition.equals(right_up)){
            if(debug) {
                System.out.println("REM в правом верхнем углу");
            }
            rem_start = start_position_type.right_up;
        }
        if(REMSquadPosition.equals(right_down)){
            if(debug) {
                System.out.println("REM внизу");
            }
            rem_start = start_position_type.right_down;
        }

        //Находим позицию TANK:
        if(TANKSquadPosition.equals(down)){
            if(debug) {
                System.out.println("tank внизу");
            }
            tank_start = start_position_type.down;
        }
        if(TANKSquadPosition.equals(up)){
            if(debug) {
                System.out.println("tank вверху");
            }
            tank_start = start_position_type.up;
        }
        if(TANKSquadPosition.equals(left)){
            if(debug) {
                System.out.println("tank слева");
            }
            tank_start = start_position_type.left;
        }
        if(TANKSquadPosition.equals(right)){
            if(debug) {
                System.out.println("tank справа");
            }
            tank_start = start_position_type.right;
        }
        if(TANKSquadPosition.equals(left_up)){
            if(debug) {
                System.out.println("tank в левом верхнем углу");
            }
            tank_start = start_position_type.left_up;
        }
        if(TANKSquadPosition.equals(left_down)){
            if(debug) {
                System.out.println("tank в нижнем левом углу");
            }
            tank_start = start_position_type.left_down;
        }
        if(TANKSquadPosition.equals(center)){
            if(debug) {
                System.out.println("tank по центру");
            }
            tank_start = start_position_type.center;
        }
        if(TANKSquadPosition.equals(right_up)){
            if(debug) {
                System.out.println("tank в правом верхнем углу");
            }
            tank_start = start_position_type.right_up;
        }
        if(TANKSquadPosition.equals(right_down)){
            if(debug) {
                System.out.println("tank внизу");
            }
            tank_start = start_position_type.right_down;
        }

        //Находим позицию BMP:
        if(BMPSquadPosition.equals(down)){
            if(debug) {
                System.out.println("bmp внизу");
            }
            bmp_start = start_position_type.down;
        }
        if(BMPSquadPosition.equals(up)){
            if(debug) {
                System.out.println("bmp вверху");
            }
            bmp_start = start_position_type.up;
        }
        if(BMPSquadPosition.equals(left)){
            if(debug) {
                System.out.println("bmp слева");
            }
            bmp_start = start_position_type.left;
        }
        if(BMPSquadPosition.equals(right)){
            if(debug) {
                System.out.println("bmp справа");
            }
            bmp_start = start_position_type.right;
        }
        if(BMPSquadPosition.equals(left_up)){
            if(debug) {
                System.out.println("bmp в левом верхнем углу");
            }
            bmp_start = start_position_type.left_up;
        }
        if(BMPSquadPosition.equals(left_down)){
            if(debug) {
                System.out.println("bmp в нижнем левом углу");
            }
            bmp_start = start_position_type.left_down;
        }
        if(BMPSquadPosition.equals(center)){
            if(debug) {
                System.out.println("bmp по центру");
            }
            bmp_start = start_position_type.center;
        }
        if(BMPSquadPosition.equals(right_up)){
            if(debug) {
                System.out.println("bmp в правом верхнем углу");
            }
            bmp_start = start_position_type.right_up;
        }
        if(BMPSquadPosition.equals(right_down)){
            if(debug) {
                System.out.println("bmp в нижнем правом углу");
            }
            bmp_start = start_position_type.right_down;
        }
    }

    //----------------------------------Упрощение команд----------------------------------------

    // Метод создает и добавляет в очередь move с выделением указанного.
    // Unit-а(
    // 0 - CLEAR_AND_DESELECT очистить предыдущее выделение и создать новое,
    // 1 - ADD_TO_SELECTION добавить к выделенному)
    // 2 - выбрать все юниты указанного типа
    void selectVehicle(Vehicle vehicle, int select_type, Order order, double x, double y, double x2, double y2, int group_number) {

        switch (select_type) {
            //Очищаем предыдущее и выполняем новое выделение:
            case 0:
                // .. и добавляем в очередь отложенные действия для выделения и перемещения техники.
                    //Всегда добавляем в счетчик выполненное действие:
                    if(action < actionCount){
                        move.setAction(ActionType.CLEAR_AND_SELECT);
                        move.setLeft(x);
                        move.setTop(y);
                        move.setRight(x2);
                        move.setBottom(y2);
                        action += 1;
                        order.complete = true;
                        if(debug) {
                            System.out.println("Отдан приказ о очищении текущего выбора и новом выборе техники");
                        }
                    }
                break;
            //Выделяем и добавляем новый юнит к текущим выделенным:
            case 1:
                    //Всегда добавляем в счетчик выполненное действие:
                    if(action < actionCount){
                        move.setAction(ActionType.ADD_TO_SELECTION);
                        move.setLeft(x);
                        move.setTop(y);
                        move.setRight(x2);
                        move.setBottom(y2);
                        action += 1;
                        order.complete = true;
                        if(debug) {
                            System.out.println("Отдан приказ о добавлении техники к текущему выбору");
                        }
                    }
                break;
            //Выделяем все юниты только указанного типа:
            case 2:
                //Всегда добавляем в счетчик выполненное действие:
                if(action < actionCount){
                    move.setAction(ActionType.ADD_TO_SELECTION);
                    move.setVehicleType(vehicle.getType());
                    move.setRight(world.getWidth());
                    move.setBottom(world.getHeight());
                    action += 1;
                    order.complete = true;
                    if(debug) {
                        System.out.println("Отдан приказ о добавлении техники к текущему выбору");
                    }
                }
                break;
            case 3:
                //Всегда добавляем в счетчик выполненное действие:
                if(action < actionCount){
                    move.setAction(ActionType.ADD_TO_SELECTION);
                    move.setLeft(x);
                    move.setTop(y);
                    move.setRight(x2);
                    move.setBottom(y2);
                    action += 1;
                    order.complete = true;
                    if(debug) {
                        System.out.println("Отдан приказ о очищении текущего выбора и новом выборе техники");
                    }
                }
                break;
            case 4:
                //Выбираем в новое выделение уже созданный одряд с номером:
                if(action < actionCount){
                    move.setAction(ActionType.CLEAR_AND_SELECT);
                    move.setGroup(group_number);
                    action += 1;
                    order.complete = true;
                    if(debug) {
                        System.out.println("Отдан приказ о новом выделении техники с назначенным номером группы: " + group_number);
                    }
                }
            case 5:
                //добавляем новые юниты из группыс номером, в уже существущий отряд:
                if(action < actionCount){
                    move.setAction(ActionType.ADD_TO_SELECTION);
                    move.setGroup(group_number);
                    action += 1;
                    order.complete = true;
                    if(debug) {
                        System.out.println("Отдан приказ о новом выделении техники с назначенным номером группы: " + group_number);
                    }
                }
                break;
            //Выделяем все юниты только указанного типа(новое выделение):
            case 6:
                //Всегда добавляем в счетчик выполненное действие:
                if(action < actionCount){
                    move.setAction(ActionType.CLEAR_AND_SELECT);
                    move.setVehicleType(vehicle.getType());
                    move.setRight(world.getWidth());
                    move.setBottom(world.getHeight());
                    action += 1;
                    order.complete = true;
                    if(debug) {
                        System.out.println("Отдан приказ о новом выборе");
                    }
                }
                break;
        }
    }

    //Метод создает приказ двигаться в указанную точку.
    void moveOrder(double x, double y, Order order, int group_number){
        //Всегда добавляем в счетчик выполненное действие:
        if(action < actionCount){
            move.setAction(ActionType.MOVE);
            move.setX(x);
            move.setY(y);
            action += 1;
            order.complete = true;
            if(debug) {
                System.out.println("Отдан приказ о перемещении техники, в точку: x = " + x + ", y = " + y);
            }
        }
    }

    //Метод создает или уничтожает группу с заданным номером(
    // 0 - разформировать,
    // 1 - создать,
    // 2 - убрать у выделенных юнитов принадлежность к группе)
    //(необходимо предварительно выделить юниты)
    void groupOrder(int group_number, int modificator, Order order){
        switch(modificator){
            case 0:
                //Всегда добавляем в счетчик выполненное действие:
                if(action < actionCount){
                    move.setAction(ActionType.DISBAND);
                    move.setGroup(group_number);
                    action += 1;
                    order.complete = true;
                    if(debug) {
                        System.out.println("Отдан приказ разформировать группу техники № " + group_number);
                    }
                }
                break;
            case 1:
                //Всегда добавляем в счетчик выполненное действие:
                if(action < actionCount){
                    move.setAction(ActionType.ASSIGN);
                    move.setGroup(group_number);
                    action += 1;
                    order.complete = true;
                    if(debug) {
                        System.out.println("Отдан приказ о создании группы техники № " + group_number);
                    }
                }
                break;
            case 2:
                if(action < actionCount){
                    move.setAction(ActionType.DISMISS);
                    move.setGroup(group_number);
                    //Всегда добавляем в счетчик выполненное действие:
                    action += 1;
                    order.complete = true;
                    if(debug) {
                        System.out.println("Отдан приказ о исключении выделенных едениц техники из группы № " + group_number);
                    }
                }
                break;
        }
    }

    //Метод выполняет создание ордера о перемещении, и добавление этого ордера в очередь.
    void setMoveOrder(double x, double y, int group_number){
        Order moves = new Order();
        moves.type = Order.type_order.move;
        moves.group_number = group_number;
        moves.x = x;
        moves.y = y;
        allOrder.add(moves);
    }

    //Метод выполняет создание ордера о выделении войск.
    void setSelectOrder(int type_select, Vehicle target_vehicle, double x, double y, double x2, double y2, int group_number){
        Order select = new Order();
        select.type = Order.type_order.select;
        select.modificator = type_select;
        select.target_vehicle = target_vehicle;
        select.x = x;
        select.y = y;
        select.x2 = x2;
        select.y2 = y2;
        select.group_number = group_number;
        allOrder.add(select);
    }

    //Метод позволяет отдать приказ на управление группами:
    void setGroupOrder(int group_number, int type){
        Order select = new Order();
        select.type = Order.type_order.group;
        select.modificator = type;
        select.group_number = group_number;
        allOrder.add(select);
    }

    void test(){
        // первая такика будет заключаться в поспешном формировании
        // нескольких узкоспециализированных отрядов.
        // Определяем отряды снизу вверх(первыми по скорости нападут воздушные юниты
        // Заача как можно быстрее сформировать заслонные атакующие отряды:

        //рассчитываем ширину и высоту для выделения половины отряда:
        //double lenght_x = (center.x - left.x)/2;
        //double height_y = (center.y - up.y)/2;

        //И так подготавливаем управление для нашего командира:
        //1. выделение одного типа войск происходит за 1 действие.

        //--------------------------------------------НИЖНЯЯ ЧАСТЬ
        /*
        //Выделяем верхнюю половину самолетов:
        setSelectOrder(0, FIGHTERList.get(0),
                (FIGHTERSquadPosition.x - lenght_x), (FIGHTERSquadPosition.y),
                FIGHTERSquadPosition.x + lenght_x, FIGHTERSquadPosition.y + height_y);

        //Выделяем верхнюю половину танков:
        setSelectOrder(3, TANKList.get(0),
                (TANKSquadPosition.x - lenght_x), (TANKSquadPosition.y),
                TANKSquadPosition.x + lenght_x, TANKSquadPosition.y + height_y);

        //Выделяем верхнюю половину Rem
        setSelectOrder(3, REMList.get(0),
                (REMSquadPosition.x - lenght_x), (REMSquadPosition.y),
                REMSquadPosition.x + lenght_x, REMSquadPosition.y + height_y);

        // Назначаем выделенным юнитам группу:
        setGroupOrder(0,1);

        //Приказываем новому отряду выдвинуться на позицию:
        setMoveOrder(200,200);

        /*
        //--------------------------------------------ВЕРХНЯЯ ЧАСТЬ
        //Выделяем верхнюю половину самолетов:
        setSelectOrder(0, FIGHTERList.get(0),
                (FIGHTERSquadPosition.x - lenght_x), (FIGHTERSquadPosition.y - height_y),
                FIGHTERSquadPosition.x + lenght_x, FIGHTERSquadPosition.y);

        //Выделяем верхнюю половину танков:
        setSelectOrder(3, TANKList.get(0),
                (TANKSquadPosition.x - lenght_x), (TANKSquadPosition.y - height_y),
                TANKSquadPosition.x + lenght_x, TANKSquadPosition.y);

        //Выделяем верхнюю половину Rem
        setSelectOrder(3, REMList.get(0),
                (REMSquadPosition.x - lenght_x), (REMSquadPosition.y - height_y),
                REMSquadPosition.x + lenght_x, REMSquadPosition.y);

        // Назначаем выделенным юнитам группу:
        setGroupOrder(1,1);

        //Приказываем новому отряду выдвинуться на позицию:
        setMoveOrder(250,200);
        */
    }
}

import model.Vehicle;
import model.VehicleType;

import java.util.*;

//Отряд:
public class Squad {

    //Полученный отрядом активный ордер(тут будем выполнять проверку на выполение):
    public Order active_order = null;

    //Позиция назначения:
    public Position targetPosition = null;

    public MyStrategy stratsegy = null;

    // Сектор в котором на данный момент находится отряд
    // (желательно давать точку назначения как одну из точек сектора, например центральную).
    public Sector squadSector = null;

    //Дистанция, до точки назначения, на которой считается что юнит достиг точки назначения, order выполнен.
    public double stop_distance = 1.5;

    //Номер присвоенный данному отряду(наземные еденицы);
    public int squad_number = 0;

    //Номер присвоенный данному отряду(воздушные еденицы);
    public int avia_squad_number = 0;

    //Список всей техники в данном отряде:
    public ArrayList<Long> allSquadVehicle = new ArrayList<>();

    public int HELECOPTERVehicleInSquadCount = 0;
    public int FIGHTERVehicleInSquadCount = 0;
    public int TANKVehicleInSquadCount = 0;
    public int BTRVehicleInSquadCount = 0;
    public int REMVehicleInSquad = 0;
    public int allUnitInSquad = 0;

    //Статус текущего отряда
    public status_squad status;
    public enum status_squad{
        wait,                                       //Ожидает приказов.
        move,                                       //Выдвигается.
        defends,                                    //Защищается.
        wait_for_atack,                             //Ожидает атаки.
    }

    public Squad(MyStrategy strategy){
        this.stratsegy = strategy;
    }

    // Метод актуализирует информацию о отряде.
    public void updateSquadInfo(){

        REMVehicleInSquad = 0;
        FIGHTERVehicleInSquadCount = 0;
        HELECOPTERVehicleInSquadCount = 0;
        BTRVehicleInSquadCount = 0;
        TANKVehicleInSquadCount = 0;

        //Подсчитываем сколько всего юнитов в отряде;
        allUnitInSquad = allSquadVehicle.size();

        //Сортируем по типам всю технику в отряде;
        for(int i = 0; i < allSquadVehicle.size(); i++){
            Vehicle vehicle = stratsegy.getVehicleByID(allSquadVehicle.get(i));
            //Выполняю сортировку и добавление техники в списки:
            VehicleType type = vehicle.getType();
            switch(type){
                case ARRV:
                    REMVehicleInSquad ++;
                    break;
                case FIGHTER:
                    FIGHTERVehicleInSquadCount ++;
                    break;
                case HELICOPTER:
                    HELECOPTERVehicleInSquadCount ++;
                    break;
                case IFV:
                    BTRVehicleInSquadCount ++;
                    break;
                case TANK:
                    TANKVehicleInSquadCount ++;
                    break;
            }
        }
    }

    //Данный метод проверяет достижение этим отрядом целевого сектора, для отмены приказа.
    public void isCompleteOrder(){
        if(active_order != null){
            //После достижения хотя бы одной еденицы из данного отряда целевого сектора отменяем текущий приказ.
            for(int i = 0; i < allSquadVehicle.size(); i++){
                Vehicle nextVehicle = stratsegy.getVehicleByID(allSquadVehicle.get(i));
                if(active_order.completeSector.allVehicleInSector.contains(nextVehicle)){
                    this.active_order.complete = true;
                    return;
                }
            }
        }
    }
}

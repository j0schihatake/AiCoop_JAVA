//Позиция в игровом мире это точка сформированная 2-мя координатами.
public class Position {

    //Координата X:
    public double x = 0;

    //Координата Y:
    public double y = 0;

    //Конструктор:
    Position(double x, double y){
        this.x = x;
        this.y = y;
    }

    //Реализуем сравнение позиций:
    boolean equals(Position pos){
        boolean result = false;
        //результат -1 при 1 значение меньше, 0 значения равны, 1 первое значение больше.
        //System.out.println("x = " + this.x + " x2 = " + pos.x + " результат: " + Double.compare(this.x, pos.x));
        //System.out.println("y = " + this.y + " y2 = " + pos.y + " результат: " + Double.compare(this.y, pos.y));
        if((Double.compare(this.x, pos.x) == 0) && (Double.compare(this.y, pos.y) == 0)){
            result = true;
        }
        return result;
    }
}
